How  Install and Run EngiCalc

1. First install Node.js and MongoDB

2. Extract project ZIP file.

3. Open backend folder on terminal.

4. Install packages

   npm install

5. Make sure MongoDB service is running.

6. Run backend

   node server.js

7. Open another terminal and go to frontend folder.

8. Install packages

   npm install

9. Start frontend

    npm run dev

11. Open browser and go to

    http://localhost:5173

Keep both terminals running when using website.