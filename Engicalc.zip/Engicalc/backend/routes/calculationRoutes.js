
const express = require('express')
const mongoose = require('mongoose')
const Calculation = require('../models/Calculation')

const router = express.Router()

// CREATE — Save a new calculation
router.post('/', async (req, res) => {
  try {
    const { calculatorType, title, inputs, result, notes } = req.body

    if (
      typeof calculatorType !== 'string' ||
      !calculatorType.trim() ||
      typeof title !== 'string' ||
      !title.trim() ||
      !inputs ||
      typeof inputs !== 'object' ||
      Array.isArray(inputs) ||
      typeof result !== 'string' ||
      !result.trim()
    ) {
      return res.status(400).json({
        message: 'Please provide a calculator type, title, inputs, and result.',
      })
    }

    const calculation = await Calculation.create({
      calculatorType,
      title,
      inputs,
      result,
      notes: typeof notes === 'string' ? notes : '',
    })

    res.status(201).json(calculation)
  } catch (error) {
    res.status(500).json({
      message: 'Failed to save calculation.',
    })
  }
})

// READ — Get all saved calculations
router.get('/', async (req, res) => {
  try {
    const calculations = await Calculation.find().sort({ createdAt: -1 })
    res.json(calculations)
  } catch (error) {
    res.status(500).json({
      message: 'Failed to retrieve calculations.',
    })
  }
})

// UPDATE — Edit an existing calculation
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params

    if (!mongoose.isObjectIdOrHexString(id)) {
      return res.status(400).json({
        message: 'Invalid calculation ID.',
      })
    }

    const { calculatorType, title, inputs, result, notes } = req.body

    if (
      typeof calculatorType !== 'string' ||
      !calculatorType.trim() ||
      typeof title !== 'string' ||
      !title.trim() ||
      !inputs ||
      typeof inputs !== 'object' ||
      Array.isArray(inputs) ||
      typeof result !== 'string' ||
      !result.trim() ||
      (notes !== undefined && typeof notes !== 'string')
    ) {
      return res.status(400).json({
        message: 'Please provide valid calculation details.',
      })
    }

    const updatedCalculation = await Calculation.findByIdAndUpdate(
      id,
      {
        calculatorType,
        title,
        inputs,
        result,
        notes: notes ?? '',
      },
      {
        new: true,
        runValidators: true,
      }
    )

    if (!updatedCalculation) {
      return res.status(404).json({
        message: 'Calculation not found.',
      })
    }

    res.json(updatedCalculation)
  } catch (error) {
    res.status(500).json({
      message: 'Failed to update calculation.',
    })
  }
})

// DELETE — Remove an existing calculation
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params

    if (!mongoose.isObjectIdOrHexString(id)) {
      return res.status(400).json({
        message: 'Invalid calculation ID.',
      })
    }

    const deletedCalculation = await Calculation.findByIdAndDelete(id)

    if (!deletedCalculation) {
      return res.status(404).json({
        message: 'Calculation not found.',
      })
    }

    res.json({
      message: 'Calculation deleted successfully.',
    })
  } catch (error) {
    res.status(500).json({
      message: 'Failed to delete calculation.',
    })
  }
})

module.exports = router
