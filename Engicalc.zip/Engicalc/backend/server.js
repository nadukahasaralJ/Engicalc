
const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
require('dotenv').config()

const calculationRoutes = require('./routes/calculationRoutes')

const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())

// Test route
app.get('/', (req, res) => {
  res.send('EngiCalc Backend Server is Running!')
})

// Calculation API routes
app.use('/api/calculations', calculationRoutes)

// Connect to MongoDB, then start the backend
async function startServer() {
  try {
    await mongoose.connect(process.env.MONGO_URI)

    console.log('MongoDB connected successfully!')

    app.listen(PORT, () => {
      console.log(`EngiCalc backend running at http://localhost:${PORT}`)
    })
  } catch (error) {
    console.error('MongoDB connection failed:', error.message)
    process.exit(1)
  }
}

startServer()
