
const mongoose = require('mongoose')

const calculationSchema = new mongoose.Schema(
  {
    calculatorType: {
      type: String,
      required: true,
      trim: true,
    },

    title: {
      type: String,
      required: true,
      trim: true,
    },

    inputs: {
      type: mongoose.Schema.Types.Mixed,
      required: true,
    },

    result: {
      type: String,
      required: true,
    },

    notes: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
)

module.exports = mongoose.model('Calculation', calculationSchema)
