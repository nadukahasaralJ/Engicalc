
import { useState } from 'react'
import { saveCalculation } from './calculationApi'

const inputStyle = {
  width: '100%',
  padding: '12px',
  marginTop: '6px',
  marginBottom: '16px',
  border: '1px solid #dce3ee',
  borderRadius: '8px',
  fontSize: '15px',
  boxSizing: 'border-box',
}

const buttonStyle = {
  padding: '12px 20px',
  border: 'none',
  borderRadius: '8px',
  background: '#2563eb',
  color: 'white',
  cursor: 'pointer',
  fontWeight: 600,
}

function NumberField({ label, value, onChange, placeholder }) {
  return (
    <label style={{ display: 'block', fontWeight: 600 }}>
      {label}
      <input
        style={inputStyle}
        type="number"
        step="any"
        value={value}
        placeholder={placeholder || 'Enter a value'}
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  )
}

function Result({ result, error }) {
  return (
    <>
      {error && (
        <p role="alert" style={{ color: '#dc2626', fontWeight: 600 }}>
          {error}
        </p>
      )}
      {result && (
        <div
          role="status"
          style={{
            background: '#ecfdf5',
            color: '#047857',
            padding: '16px',
            borderRadius: '8px',
            marginTop: '16px',
            whiteSpace: 'pre-line',
            fontWeight: 600,
            overflowWrap: 'anywhere',
          }}
        >
          {result}
        </div>
      )}
    </>
  )
}

// Reusable Save button for all calculators
function SaveResult({ calculatorType, inputs, result }) {
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState('')
  const [saved, setSaved] = useState(false)

  async function handleSave() {
    if (!result || !inputs || saving || saved) return

    setSaving(true)
    setMessage('')

    try {
      await saveCalculation({
        calculatorType,
        title: `${calculatorType} Calculation`,
        inputs,
        result,
        notes: 'Saved from the EngiCalc website',
      })

      setSaved(true)
      setMessage('Calculation saved successfully!')
    } catch (error) {
      console.error('Save failed:', error)
      setMessage('Failed to save calculation. Check your backend server.')
    } finally {
      setSaving(false)
    }
  }

  if (!result || !inputs) return null

  return (
    <div style={{ marginTop: '16px' }}>
      <button
        style={{
          ...buttonStyle,
          background: saved ? '#64748b' : '#059669',
          opacity: saving ? 0.7 : 1,
        }}
        onClick={handleSave}
        disabled={saving || saved}
      >
        {saving ? 'Saving...' : saved ? 'Saved ✓' : 'Save Calculation'}
      </button>

      {message && (
        <p
          role="status"
          style={{
            marginTop: '12px',
            fontWeight: 600,
            color: saved ? '#047857' : '#dc2626',
          }}
        >
          {message}
        </p>
      )}
    </div>
  )
}

// OHM'S LAW
function OhmsLaw() {
  const [voltage, setVoltage] = useState('')
  const [current, setCurrent] = useState('')
  const [resistance, setResistance] = useState('')
  const [result, setResult] = useState('')
  const [error, setError] = useState('')
  const [calculatedInputs, setCalculatedInputs] = useState(null)

  function clearResult() {
    setResult('')
    setError('')
    setCalculatedInputs(null)
  }

  function calculate() {
    clearResult()

    const values = [voltage, current, resistance]
    const filled = values.filter((value) => value.trim() !== '')

    if (filled.length !== 2) {
      setError('Enter exactly two values and leave the third empty.')
      return
    }

    const [v, i, r] = values.map((value) =>
      value.trim() === '' ? null : Number(value)
    )

    if (
      [v, i, r].some(
        (value) =>
          value !== null &&
          (!Number.isFinite(value) || value < 0)
      )
    ) {
      setError('Enter valid non-negative numbers.')
      return
    }

    const originalInputs = {
      voltage: v,
      current: i,
      resistance: r,
    }

    if (v === null) {
      const answer = i * r
      if (!Number.isFinite(answer)) {
        setError('Result is too large.')
        return
      }
      setVoltage(String(answer))
      setResult(`Voltage = ${answer.toFixed(4)} V`)
    } else if (i === null) {
      if (r === 0) {
        setError('Resistance cannot be zero when calculating current.')
        return
      }
      const answer = v / r
      if (!Number.isFinite(answer)) {
        setError('Result is too large.')
        return
      }
      setCurrent(String(answer))
      setResult(`Current = ${answer.toFixed(4)} A`)
    } else {
      if (i === 0) {
        setError('Current cannot be zero when calculating resistance.')
        return
      }
      const answer = v / i
      if (!Number.isFinite(answer)) {
        setError('Result is too large.')
        return
      }
      setResistance(String(answer))
      setResult(`Resistance = ${answer.toFixed(4)} Ω`)
    }

    setCalculatedInputs(originalInputs)
  }

  function reset() {
    setVoltage('')
    setCurrent('')
    setResistance('')
    clearResult()
  }

  return (
    <>
      <h2>Ohm's Law Calculator</h2>
      <p>Enter any two values and leave the third empty.</p>

      <NumberField
        label="Voltage (V)"
        value={voltage}
        onChange={(value) => {
          setVoltage(value)
          clearResult()
        }}
      />
      <NumberField
        label="Current (A)"
        value={current}
        onChange={(value) => {
          setCurrent(value)
          clearResult()
        }}
      />
      <NumberField
        label="Resistance (Ω)"
        value={resistance}
        onChange={(value) => {
          setResistance(value)
          clearResult()
        }}
      />

      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        <button style={buttonStyle} onClick={calculate}>
          Calculate
        </button>
        <button
          style={{ ...buttonStyle, background: '#64748b' }}
          onClick={reset}
        >
          Reset
        </button>
      </div>

      <Result result={result} error={error} />

      {result && (
        <SaveResult
          key={result + JSON.stringify(calculatedInputs)}
          calculatorType="Ohm's Law"
          inputs={calculatedInputs}
          result={result}
        />
      )}
    </>
  )
}

// ELECTRICAL POWER
function ElectricalPower() {
  const [voltage, setVoltage] = useState('')
  const [current, setCurrent] = useState('')
  const [result, setResult] = useState('')
  const [error, setError] = useState('')
  const [calculatedInputs, setCalculatedInputs] = useState(null)

  function clearResult() {
    setResult('')
    setError('')
    setCalculatedInputs(null)
  }

  function calculate() {
    clearResult()

    if (voltage.trim() === '' || current.trim() === '') {
      setError('Enter both voltage and current.')
      return
    }

    const v = Number(voltage)
    const i = Number(current)

    if (!Number.isFinite(v) || !Number.isFinite(i)) {
      setError('Enter valid numbers.')
      return
    }

    const power = v * i

    if (!Number.isFinite(power)) {
      setError('Result is too large.')
      return
    }

    setResult(`Electrical Power = ${power.toFixed(4)} W`)
    setCalculatedInputs({ voltage: v, current: i })
  }

  return (
    <>
      <h2>Electrical Power Calculator</h2>
      <p>Calculate DC electrical power using P = V × I.</p>

      <NumberField
        label="Voltage (V)"
        value={voltage}
        onChange={(value) => {
          setVoltage(value)
          clearResult()
        }}
      />
      <NumberField
        label="Current (A)"
        value={current}
        onChange={(value) => {
          setCurrent(value)
          clearResult()
        }}
      />

      <button style={buttonStyle} onClick={calculate}>
        Calculate Power
      </button>

      <Result result={result} error={error} />

      {result && (
        <SaveResult
          key={result + JSON.stringify(calculatedInputs)}
          calculatorType="Electrical Power"
          inputs={calculatedInputs}
          result={result}
        />
      )}
    </>
  )
}

// VOLTAGE DIVIDER
function VoltageDivider() {
  const [inputVoltage, setInputVoltage] = useState('')
  const [r1, setR1] = useState('')
  const [r2, setR2] = useState('')
  const [result, setResult] = useState('')
  const [error, setError] = useState('')
  const [calculatedInputs, setCalculatedInputs] = useState(null)

  function clearResult() {
    setResult('')
    setError('')
    setCalculatedInputs(null)
  }

  function calculate() {
    clearResult()

    if (
      inputVoltage.trim() === '' ||
      r1.trim() === '' ||
      r2.trim() === ''
    ) {
      setError('Please fill in all fields.')
      return
    }

    const vin = Number(inputVoltage)
    const resistor1 = Number(r1)
    const resistor2 = Number(r2)

    if (
      ![vin, resistor1, resistor2].every(Number.isFinite) ||
      resistor1 < 0 ||
      resistor2 < 0 ||
      resistor1 + resistor2 === 0
    ) {
      setError(
        'Use valid values. Resistors must be non-negative and their sum must be greater than zero.'
      )
      return
    }

    const output = vin * (resistor2 / (resistor1 + resistor2))

    if (!Number.isFinite(output)) {
      setError('Result is too large.')
      return
    }

    setResult(`Output Voltage = ${output.toFixed(4)} V`)
    setCalculatedInputs({
      inputVoltage: vin,
      r1: resistor1,
      r2: resistor2,
    })
  }

  return (
    <>
      <h2>Voltage Divider Calculator</h2>
      <p>For two series resistors, calculate the voltage across R2.</p>

      <NumberField
        label="Input Voltage (V)"
        value={inputVoltage}
        onChange={(value) => {
          setInputVoltage(value)
          clearResult()
        }}
      />
      <NumberField
        label="R1 (Ω)"
        value={r1}
        onChange={(value) => {
          setR1(value)
          clearResult()
        }}
      />
      <NumberField
        label="R2 (Ω)"
        value={r2}
        onChange={(value) => {
          setR2(value)
          clearResult()
        }}
      />

      <button style={buttonStyle} onClick={calculate}>
        Calculate Output Voltage
      </button>

      <Result result={result} error={error} />

      {result && (
        <SaveResult
          key={result + JSON.stringify(calculatedInputs)}
          calculatorType="Voltage Divider"
          inputs={calculatedInputs}
          result={result}
        />
      )}
    </>
  )
}

// THREE-PHASE POWER
function ThreePhasePower() {
  const [connection, setConnection] = useState('star')
  const [inputMode, setInputMode] = useState('line')
  const [voltage, setVoltage] = useState('')
  const [current, setCurrent] = useState('')
  const [powerFactor, setPowerFactor] = useState('')
  const [result, setResult] = useState('')
  const [error, setError] = useState('')
  const [calculatedInputs, setCalculatedInputs] = useState(null)

  function clearResult() {
    setResult('')
    setError('')
    setCalculatedInputs(null)
  }

  function calculate() {
    clearResult()

    if (
      voltage.trim() === '' ||
      current.trim() === '' ||
      powerFactor.trim() === ''
    ) {
      setError('Please enter voltage, current, and power factor.')
      return
    }

    const v = Number(voltage)
    const i = Number(current)
    const pf = Number(powerFactor)
    const sqrt3 = Math.sqrt(3)

    if (
      ![v, i, pf].every(Number.isFinite) ||
      v < 0 ||
      i < 0 ||
      pf < 0 ||
      pf > 1
    ) {
      setError(
        'Voltage and current must be non-negative. Power factor must be between 0 and 1.'
      )
      return
    }

    let lineVoltage
    let phaseVoltage
    let lineCurrent
    let phaseCurrent

    if (connection === 'star') {
      if (inputMode === 'line') {
        lineVoltage = v
        phaseVoltage = v / sqrt3
        lineCurrent = i
        phaseCurrent = i
      } else {
        phaseVoltage = v
        lineVoltage = v * sqrt3
        phaseCurrent = i
        lineCurrent = i
      }
    } else {
      if (inputMode === 'line') {
        lineVoltage = v
        phaseVoltage = v
        lineCurrent = i
        phaseCurrent = i / sqrt3
      } else {
        phaseVoltage = v
        lineVoltage = v
        phaseCurrent = i
        lineCurrent = i * sqrt3
      }
    }

    const apparentPower = sqrt3 * lineVoltage * lineCurrent
    const realPower = apparentPower * pf
    const reactivePower =
      apparentPower * Math.sqrt(Math.max(0, 1 - pf * pf))

    if (
      ![
        lineVoltage,
        phaseVoltage,
        lineCurrent,
        phaseCurrent,
        apparentPower,
        realPower,
        reactivePower,
      ].every(Number.isFinite)
    ) {
      setError('Result is too large.')
      return
    }

    setResult(
      `Connection: ${connection === 'star' ? 'Star (Y)' : 'Delta (Δ)'}\n\n` +
      `LINE PARAMETERS\n` +
      `Line Voltage = ${lineVoltage.toFixed(4)} V\n` +
      `Line Current = ${lineCurrent.toFixed(4)} A\n\n` +
      `PHASE PARAMETERS\n` +
      `Phase Voltage = ${phaseVoltage.toFixed(4)} V\n` +
      `Phase Current = ${phaseCurrent.toFixed(4)} A\n\n` +
      `THREE-PHASE POWER\n` +
      `Real Power (P) = ${realPower.toFixed(4)} W\n` +
      `Reactive Power (Q) = ${reactivePower.toFixed(4)} VAR\n` +
      `Apparent Power (S) = ${apparentPower.toFixed(4)} VA\n` +
      `Power Factor = ${pf.toFixed(4)}`
    )

    setCalculatedInputs({
      connection,
      inputMode,
      voltage: v,
      current: i,
      powerFactor: pf,
    })
  }

  function reset() {
    setVoltage('')
    setCurrent('')
    setPowerFactor('')
    clearResult()
  }

  function changeConnection(value) {
    setConnection(value)
    clearResult()
  }

  function changeInputMode(value) {
    setInputMode(value)
    setVoltage('')
    setCurrent('')
    clearResult()
  }

  return (
    <>
      <h2>Three-Phase Power Calculator</h2>
      <p>
        Calculate line parameters, phase parameters, and total
        power for a balanced three-phase AC system.
      </p>

      <label style={{ display: 'block', fontWeight: 600 }}>
        Connection Type
        <select
          style={inputStyle}
          value={connection}
          onChange={(event) => changeConnection(event.target.value)}
        >
          <option value="star">Star (Y)</option>
          <option value="delta">Delta (Δ)</option>
        </select>
      </label>

      <label style={{ display: 'block', fontWeight: 600 }}>
        Input Parameters
        <select
          style={inputStyle}
          value={inputMode}
          onChange={(event) => changeInputMode(event.target.value)}
        >
          <option value="line">Line Voltage and Line Current</option>
          <option value="phase">Phase Voltage and Phase Current</option>
        </select>
      </label>

      <div
        style={{
          background: '#eff6ff',
          padding: '14px',
          borderRadius: '8px',
          marginBottom: '18px',
          color: '#1d4ed8',
        }}
      >
        <strong>
          {connection === 'star' ? 'Star (Y)' : 'Delta (Δ)'} Relationships
        </strong>

        {connection === 'star' ? (
          <p style={{ marginBottom: 0 }}>
            VL = √3 × Vph
            <br />
            IL = Iph
          </p>
        ) : (
          <p style={{ marginBottom: 0 }}>
            VL = Vph
            <br />
            IL = √3 × Iph
          </p>
        )}
      </div>

      <NumberField
        label={
          inputMode === 'line'
            ? 'Line Voltage (V)'
            : 'Phase Voltage (V)'
        }
        value={voltage}
        onChange={(value) => {
          setVoltage(value)
          clearResult()
        }}
      />

      <NumberField
        label={
          inputMode === 'line'
            ? 'Line Current (A)'
            : 'Phase Current (A)'
        }
        value={current}
        onChange={(value) => {
          setCurrent(value)
          clearResult()
        }}
      />

      <NumberField
        label="Power Factor (0 to 1)"
        value={powerFactor}
        onChange={(value) => {
          setPowerFactor(value)
          clearResult()
        }}
        placeholder="Example: 0.8"
      />

      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        <button style={buttonStyle} onClick={calculate}>
          Calculate
        </button>
        <button
          style={{ ...buttonStyle, background: '#64748b' }}
          onClick={reset}
        >
          Reset
        </button>
      </div>

      <Result result={result} error={error} />

      {result && (
        <SaveResult
          key={result + JSON.stringify(calculatedInputs)}
          calculatorType="Three-Phase Power"
          inputs={calculatedInputs}
          result={result}
        />
      )}

      <p style={{ fontSize: '13px', color: '#64748b', marginTop: '20px' }}>
        Assumptions: Balanced three-phase sinusoidal AC system.
        Reactive power is shown as a non-negative magnitude;
        the power factor alone does not indicate whether the
        load is leading or lagging.
      </p>
    </>
  )
}

// UNIT CONVERTER
const conversionGroups = {
  Length: {
    units: {
      'Meter (m)': 1,
      'Centimeter (cm)': 0.01,
      'Millimeter (mm)': 0.001,
      'Kilometer (km)': 1000,
      'Foot (ft)': 0.3048,
    },
  },
  Mass: {
    units: {
      'Kilogram (kg)': 1,
      'Gram (g)': 0.001,
      'Pound (lb)': 0.45359237,
    },
  },
  Pressure: {
    units: {
      'Pascal (Pa)': 1,
      'Kilopascal (kPa)': 1000,
      Bar: 100000,
      PSI: 6894.757293,
    },
  },
  Power: {
    units: {
      'Watt (W)': 1,
      'Kilowatt (kW)': 1000,
      'Horsepower (hp)': 745.699872,
    },
  },
}

function UnitConverter() {
  const [category, setCategory] = useState('Length')
  const [value, setValue] = useState('')
  const [fromUnit, setFromUnit] = useState('Meter (m)')
  const [toUnit, setToUnit] = useState('Centimeter (cm)')
  const [result, setResult] = useState('')
  const [error, setError] = useState('')
  const [calculatedInputs, setCalculatedInputs] = useState(null)

  const units = conversionGroups[category].units
  const unitNames = Object.keys(units)

  function clearResult() {
    setResult('')
    setError('')
    setCalculatedInputs(null)
  }

  function changeCategory(nextCategory) {
    const nextUnits = Object.keys(conversionGroups[nextCategory].units)
    setCategory(nextCategory)
    setFromUnit(nextUnits[0])
    setToUnit(nextUnits[1])
    clearResult()
  }

  function calculate() {
    clearResult()

    if (value.trim() === '') {
      setError('Enter a value to convert.')
      return
    }

    const number = Number(value)

    if (!Number.isFinite(number)) {
      setError('Enter a valid number.')
      return
    }

    const converted = (number * units[fromUnit]) / units[toUnit]

    if (!Number.isFinite(converted)) {
      setError('Result is too large.')
      return
    }

    setResult(
      `${number} ${fromUnit} = ${Number(converted.toPrecision(10))} ${toUnit}`
    )

    setCalculatedInputs({
      category,
      value: number,
      fromUnit,
      toUnit,
    })
  }

  return (
    <>
      <h2>Engineering Unit Converter</h2>
      <p>Convert between common engineering units.</p>

      <label style={{ display: 'block', fontWeight: 600 }}>
        Category
        <select
          style={inputStyle}
          value={category}
          onChange={(event) => changeCategory(event.target.value)}
        >
          {Object.keys(conversionGroups).map((name) => (
            <option key={name}>{name}</option>
          ))}
        </select>
      </label>

      <NumberField
        label="Value"
        value={value}
        onChange={(nextValue) => {
          setValue(nextValue)
          clearResult()
        }}
      />

      <label style={{ display: 'block', fontWeight: 600 }}>
        From
        <select
          style={inputStyle}
          value={fromUnit}
          onChange={(event) => {
            setFromUnit(event.target.value)
            clearResult()
          }}
        >
          {unitNames.map((name) => (
            <option key={name}>{name}</option>
          ))}
        </select>
      </label>

      <label style={{ display: 'block', fontWeight: 600 }}>
        To
        <select
          style={inputStyle}
          value={toUnit}
          onChange={(event) => {
            setToUnit(event.target.value)
            clearResult()
          }}
        >
          {unitNames.map((name) => (
            <option key={name}>{name}</option>
          ))}
        </select>
      </label>

      <button style={buttonStyle} onClick={calculate}>
        Convert
      </button>

      <Result result={result} error={error} />

      {result && (
        <SaveResult
          key={result + JSON.stringify(calculatedInputs)}
          calculatorType="Unit Converter"
          inputs={calculatedInputs}
          result={result}
        />
      )}
    </>
  )
}

// FORMULA LIBRARY
const formulas = [
  {
    name: "Ohm's Law",
    equation: 'V = I × R',
    description: 'Voltage equals current multiplied by resistance.',
  },
  {
    name: 'DC Electrical Power',
    equation: 'P = V × I',
    description: 'Power equals voltage multiplied by current.',
  },
  {
    name: 'Voltage Divider',
    equation: 'Vout = Vin × R2 / (R1 + R2)',
    description: 'Output voltage across the lower resistor in a series divider.',
  },
  {
    name: 'Three-Phase Real Power',
    equation: 'P = √3 × VL × IL × PF',
    description: 'Balanced three-phase real power using line values.',
  },
  {
    name: 'Electrical Energy',
    equation: 'E = P × t',
    description: 'Energy equals power multiplied by time.',
  },
  {
    name: 'Resistors in Series',
    equation: 'Req = R1 + R2 + ...',
    description: 'Total resistance for series-connected resistors.',
  },
  {
    name: 'Two Resistors in Parallel',
    equation: 'Req = (R1 × R2) / (R1 + R2)',
    description: 'Equivalent resistance for two parallel resistors.',
  },
]

function FormulaLibrary() {
  const [search, setSearch] = useState('')

  const filtered = formulas.filter((formula) =>
    `${formula.name} ${formula.equation} ${formula.description}`
      .toLowerCase()
      .includes(search.toLowerCase())
  )

  return (
    <>
      <h2>Engineering Formula Library</h2>
      <p>Search and review common electrical engineering formulas.</p>

      <input
        style={inputStyle}
        value={search}
        onChange={(event) => setSearch(event.target.value)}
        placeholder="Search formulas..."
      />

      {filtered.map((formula) => (
        <article
          key={formula.name}
          style={{
            border: '1px solid #e2e8f0',
            borderRadius: '10px',
            padding: '16px',
            marginBottom: '12px',
          }}
        >
          <h3 style={{ marginTop: 0 }}>{formula.name}</h3>
          <strong style={{ color: '#2563eb', fontSize: '18px' }}>
            {formula.equation}
          </strong>
          <p>{formula.description}</p>
        </article>
      ))}

      {filtered.length === 0 && <p>No matching formulas found.</p>}
    </>
  )
}

// MAIN CALCULATOR COMPONENT
export default function CalculatorTools({ title }) {
  const components = {
    "Ohm's Law": OhmsLaw,
    'Electrical Power': ElectricalPower,
    'Voltage Divider': VoltageDivider,
    'Three-Phase Power': ThreePhasePower,
    'Unit Converter': UnitConverter,
    'Formula Library': FormulaLibrary,
  }

  const SelectedCalculator = components[title]

  if (!SelectedCalculator) {
    return <p>Calculator not found.</p>
  }

  return (
    <section
      style={{
        maxWidth: '650px',
        margin: '30px auto',
        padding: '28px',
        background: 'white',
        border: '1px solid #e2e8f0',
        borderRadius: '16px',
        boxShadow: '0 8px 30px rgba(15, 23, 42, 0.05)',
      }}
    >
      <SelectedCalculator key={title} />
    </section>
  )
}
