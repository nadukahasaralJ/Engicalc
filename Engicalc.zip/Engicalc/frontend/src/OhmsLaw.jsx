
import { useState } from 'react'

function OhmsLaw() {
  const [voltage, setVoltage] = useState('')
  const [current, setCurrent] = useState('')
  const [resistance, setResistance] = useState('')
  const [result, setResult] = useState('')
  const [error, setError] = useState('')

  function calculate() {
    const v = voltage === '' ? null : Number(voltage)
    const i = current === '' ? null : Number(current)
    const r = resistance === '' ? null : Number(resistance)

    setError('')
    setResult('')

    if ([v, i, r].filter(value => value !== null).length !== 2) {
      setError('Enter exactly two values to calculate the third.')
      return
    }

    if ([v, i, r].some(value => value !== null && (!Number.isFinite(value) || value < 0))) {
      setError('Please enter valid, non-negative numbers.')
      return
    }

    if (v !== null && i !== null) {
      if (i === 0) {
        setError('Current must not be zero to calculate resistance.')
        return
      }
      setResistance((v / i).toString())
      setResult(`Resistance = ${(v / i).toFixed(4)} Ω`)
    } else if (v !== null && r !== null) {
      if (r === 0) {
        setError('Resistance must not be zero to calculate current.')
        return
      }
      setCurrent((v / r).toString())
      setResult(`Current = ${(v / r).toFixed(4)} A`)
    } else {
      setVoltage((i * r).toString())
      setResult(`Voltage = ${(i * r).toFixed(4)} V`)
    }
  }

  function reset() {
    setVoltage('')
    setCurrent('')
    setResistance('')
    setResult('')
    setError('')
  }

  return (
    <section style={{ maxWidth: 560, margin: '30px auto', padding: 24, background: '#fff', borderRadius: 14 }}>
      <h2>Ohm's Law Calculator</h2>
      <p>Enter exactly two values to calculate the third.</p>

      <label>
        Voltage (V)
        <input type="number" value={voltage} onChange={e => setVoltage(e.target.value)} placeholder="Enter voltage" />
      </label>

      <label>
        Current (A)
        <input type="number" value={current} onChange={e => setCurrent(e.target.value)} placeholder="Enter current" />
      </label>

      <label>
        Resistance (Ω)
        <input type="number" value={resistance} onChange={e => setResistance(e.target.value)} placeholder="Enter resistance" />
      </label>

      <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
        <button onClick={calculate}>Calculate</button>
        <button onClick={reset} type="button">Reset</button>
      </div>

      {error && <p role="alert" style={{ color: '#c62828' }}>{error}</p>}
      {result && <p role="status" style={{ color: '#16845b', fontWeight: 700 }}>{result}</p>}
    </section>
  )
}

export default OhmsLaw
