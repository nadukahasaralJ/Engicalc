
const API_URL = 'http://localhost:5000/api/calculations'

// Get all saved calculations
export async function getCalculations() {
  const response = await fetch(API_URL)

  if (!response.ok) {
    throw new Error('Failed to load calculations')
  }

  return response.json()
}

// Save a new calculation
export async function saveCalculation(calculation) {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(calculation),
  })

  if (!response.ok) {
    throw new Error('Failed to save calculation')
  }

  return response.json()
}

// Update an existing calculation
export async function updateCalculation(id, calculation) {
  const response = await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(calculation),
  })

  if (!response.ok) {
    throw new Error('Failed to update calculation')
  }

  return response.json()
}

// Delete a saved calculation
export async function deleteCalculation(id) {
  const response = await fetch(`${API_URL}/${id}`, {
    method: 'DELETE',
  })

  if (!response.ok) {
    throw new Error('Failed to delete calculation')
  }

  return response.json()
}
