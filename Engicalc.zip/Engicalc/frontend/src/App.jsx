
import { useEffect, useState } from 'react'
import CalculatorTools from './CalculatorTools'
import SavedCalculations from './SavedCalculations'
import { getCalculations } from './calculationApi'
import './App.css'

const calculators = [
  {
    title: "Ohm's Law",
    category: 'Electrical',
    description: 'Calculate voltage, current, and resistance.',
    icon: 'Ω',
    color: 'blue',
  },
  {
    title: 'Electrical Power',
    category: 'Electrical',
    description: 'Calculate electrical power from voltage and current.',
    icon: 'ϟ',
    color: 'orange',
  },
  {
    title: 'Voltage Divider',
    category: 'Electrical',
    description: 'Find output voltage across a resistor network.',
    icon: '÷',
    color: 'purple',
  },
  {
    title: 'Three-Phase Power',
    category: 'Electrical',
    description: 'Calculate power in a three-phase AC system.',
    icon: '∿',
    color: 'green',
  },
  {
    title: 'Unit Converter',
    category: 'General',
    description: 'Convert common engineering units quickly.',
    icon: '⇄',
    color: 'teal',
  },
  {
    title: 'Formula Library',
    category: 'Reference',
    description: 'Browse useful engineering formulas and equations.',
    icon: 'ƒ',
    color: 'pink',
  },
]

function App() {
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('All Tools')
  const [openCalculator, setOpenCalculator] = useState(null)
  const [savedCount, setSavedCount] = useState(null)
  const [savedRefreshKey, setSavedRefreshKey] = useState(0)

  const categories = ['All Tools', 'Electrical', 'General', 'Reference']

  useEffect(() => {
    async function loadSavedCount() {
      try {
        const calculations = await getCalculations()
        setSavedCount(calculations.length)
      } catch (error) {
        console.error('Failed to load saved calculation count:', error)
      }
    }

    loadSavedCount()
  }, [savedRefreshKey])

  const filteredCalculators = calculators.filter((calculator) => {
    const matchesSearch =
      calculator.title.toLowerCase().includes(search.toLowerCase()) ||
      calculator.description.toLowerCase().includes(search.toLowerCase())

    const matchesCategory =
      activeCategory === 'All Tools' ||
      calculator.category === activeCategory

    return matchesSearch && matchesCategory
  })

  function openTool(title) {
    setOpenCalculator(title)
    window.location.hash = 'calculator-workspace'
  }

  function closeTool() {
    setOpenCalculator(null)
    window.location.hash = 'calculators'
  }

  function showSavedCalculations() {
    setSavedRefreshKey((previous) => previous + 1)
    window.location.hash = 'saved'
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="#home">
          <span className="brand-icon">E</span>
          <span>
            <strong>EngiCalc</strong>
            <small>ENGINEERING HUB</small>
          </span>
        </a>

        <p className="nav-heading">WORKSPACE</p>

        <nav className="navigation">
          <a className="nav-link active" href="#home">
            <span>▦</span> Dashboard
          </a>

          <a className="nav-link" href="#calculators">
            <span>⊞</span> Calculators
          </a>

          <a
            className="nav-link"
            href="#saved"
            onClick={showSavedCalculations}
          >
            <span>▤</span> Saved Calculations
          </a>

          <a
            className="nav-link"
            href="#formulas"
            onClick={() => openTool('Formula Library')}
          >
            <span>ƒ</span> Formula Library
          </a>
        </nav>

        <div className="sidebar-bottom">
          <div className="sidebar-note">
            <span className="note-icon">✦</span>
            <strong>Your engineering toolkit</strong>
            <p>
              Calculate, organize, and manage your engineering work in one place.
            </p>
          </div>

          <div className="profile">
            <div className="avatar">E</div>
            <div>
              <strong>Engineering Student</strong>
              <small>Personal workspace</small>
            </div>
          </div>
        </div>
      </aside>

      <main className="main-content" id="home">
        <header className="topbar">
          <div className="breadcrumb">
            Workspace / <strong>Dashboard</strong>
          </div>

          <span className="status">
            <span /> Engineering toolkit
          </span>
        </header>

        <section className="welcome-section">
          <div>
            <p className="eyebrow">YOUR ENGINEERING WORKSPACE</p>

            <h1>
              Engineering made <span>simpler.</span>
            </h1>

            <p className="welcome-text">
              Your tools and calculations, organized in one place.
            </p>
          </div>

          <div className="welcome-symbol" aria-hidden="true">
            <span>∑</span>
            <i>+</i>
            <b>Ω</b>
          </div>
        </section>

        <section className="stats-grid" aria-label="Workspace overview">
          <article className="stat-card">
            <span className="stat-icon blue">⊞</span>
            <p>Available tools</p>
            <strong>06</strong>
            <small>Engineering utilities</small>
          </article>

          <article className="stat-card">
            <span className="stat-icon green">✓</span>
            <p>Calculation categories</p>
            <strong>03</strong>
            <small>Explore by subject</small>
          </article>

          <article className="stat-card">
            <span className="stat-icon purple">▤</span>
            <p>Saved calculations</p>
            <strong>{savedCount === null ? '—' : savedCount}</strong>
            <small>Stored in MongoDB</small>
          </article>
        </section>

        <section className="tools-section" id="calculators">
          <div className="section-heading">
            <div>
              <p className="eyebrow">TOOLS & UTILITIES</p>
              <h2>Engineering calculators</h2>
              <p>Choose a tool to get started.</p>
            </div>

            <span className="tool-count">
              {filteredCalculators.length} tools
            </span>
          </div>

          <div className="tool-controls">
            <label className="search-box">
              <span>⌕</span>

              <input
                type="search"
                placeholder="Search calculators..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>

            <div className="category-filters">
              {categories.map((category) => (
                <button
                  key={category}
                  className={
                    activeCategory === category
                      ? 'filter active-filter'
                      : 'filter'
                  }
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="calculator-grid">
            {filteredCalculators.map((calculator) => (
              <article
                className="calculator-card"
                key={calculator.title}
              >
                <div className={`calculator-icon ${calculator.color}`}>
                  {calculator.icon}
                </div>

                <span className="category-label">
                  {calculator.category}
                </span>

                <h3>{calculator.title}</h3>
                <p>{calculator.description}</p>

                <button
                  className="open-tool"
                  onClick={() => openTool(calculator.title)}
                >
                  Open calculator <span>→</span>
                </button>
              </article>
            ))}
          </div>

          {filteredCalculators.length === 0 && (
            <div className="empty-state">
              <h3>No calculators found</h3>
              <p>
                Try another search term or select a different category.
              </p>
            </div>
          )}
        </section>

        {openCalculator && (
          <div id="calculator-workspace">
            <button
              onClick={closeTool}
              style={{
                marginTop: '24px',
                padding: '12px 18px',
                border: '1px solid #dce3ee',
                borderRadius: '8px',
                background: 'white',
                color: '#202b3c',
                cursor: 'pointer',
                fontWeight: 600,
              }}
            >
              ← Back to dashboard
            </button>

            <CalculatorTools
              key={openCalculator}
              title={openCalculator}
            />
          </div>
        )}

        <section
          id="saved"
          className="tools-section"
          style={{ marginTop: '40px', scrollMarginTop: '24px' }}
        >
          <SavedCalculations key={savedRefreshKey} />
        </section>

        <footer className="footer">
          <span>
            EngiCalc · Engineering Design Calculator Hub
          </span>
          <span>Built for engineering learning</span>
        </footer>
      </main>
    </div>
  )
}

export default App
