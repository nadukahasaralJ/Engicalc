
import { useEffect, useState } from 'react'
import {
  getCalculations,
  updateCalculation,
  deleteCalculation,
} from './calculationApi'

const buttonStyle = {
  padding: '10px 16px',
  border: 'none',
  borderRadius: '8px',
  color: 'white',
  cursor: 'pointer',
  fontWeight: 600,
}

const inputStyle = {
  width: '100%',
  padding: '10px',
  marginTop: '6px',
  marginBottom: '12px',
  border: '1px solid #dce3ee',
  borderRadius: '8px',
  boxSizing: 'border-box',
  fontSize: '14px',
}

const inputLabels = {
  voltage: 'Voltage',
  current: 'Current',
  resistance: 'Resistance',
  inputVoltage: 'Input Voltage',
  r1: 'Resistor R1',
  r2: 'Resistor R2',
  connection: 'Connection Type',
  inputMode: 'Input Mode',
  powerFactor: 'Power Factor',
  category: 'Category',
  value: 'Value',
  fromUnit: 'From Unit',
  toUnit: 'To Unit',
}

function formatInputName(key) {
  if (inputLabels[key]) return inputLabels[key]

  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (letter) => letter.toUpperCase())
}

function formatInputValue(key, value) {
  if (value === null || value === undefined || value === '') {
    return 'Not entered'
  }

  if (key === 'connection') {
    if (value === 'star') return 'Star (Y)'
    if (value === 'delta') return 'Delta (Δ)'
  }

  if (key === 'inputMode') {
    if (value === 'line') return 'Line Parameters'
    if (value === 'phase') return 'Phase Parameters'
  }

  const units = {
    voltage: 'V',
    inputVoltage: 'V',
    current: 'A',
    resistance: 'Ω',
    r1: 'Ω',
    r2: 'Ω',
  }

  if (units[key]) {
    return `${value} ${units[key]}`
  }

  return String(value)
}

function CalculationInputs({ inputs }) {
  if (!inputs || typeof inputs !== 'object') {
    return <p>No input details available.</p>
  }

  const entries = Object.entries(inputs)

  if (entries.length === 0) {
    return <p>No input details available.</p>
  }

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
        gap: '10px',
        marginTop: '12px',
      }}
    >
      {entries.map(([key, value]) => (
        <div
          key={key}
          style={{
            background: '#f8fafc',
            border: '1px solid #e2e8f0',
            borderRadius: '8px',
            padding: '12px',
            minWidth: 0,
          }}
        >
          <div
            style={{
              color: '#64748b',
              fontSize: '12px',
              marginBottom: '6px',
            }}
          >
            {formatInputName(key)}
          </div>

          <div
            style={{
              color: '#0f172a',
              fontWeight: 600,
              overflowWrap: 'anywhere',
            }}
          >
            {formatInputValue(key, value)}
          </div>
        </div>
      ))}
    </div>
  )
}

function SavedCalculations() {
  const [calculations, setCalculations] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [editTitle, setEditTitle] = useState('')
  const [editNotes, setEditNotes] = useState('')
  const [busyId, setBusyId] = useState(null)
  const [search, setSearch] = useState('')

  async function loadCalculations() {
    try {
      setError('')
      const data = await getCalculations()
      setCalculations(data)
    } catch (err) {
      console.error('Load failed:', err)
      setError('Could not load saved calculations.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadCalculations()
  }, [])

  function startEditing(calculation) {
    setEditingId(calculation._id)
    setEditTitle(calculation.title)
    setEditNotes(calculation.notes || '')
    setMessage('')
    setError('')
  }

  function cancelEditing() {
    setEditingId(null)
    setEditTitle('')
    setEditNotes('')
  }

  async function handleUpdate(calculation) {
    if (!editTitle.trim()) {
      setError('Calculation title cannot be empty.')
      return
    }

    setBusyId(calculation._id)
    setError('')
    setMessage('')

    try {
      await updateCalculation(calculation._id, {
        calculatorType: calculation.calculatorType,
        title: editTitle.trim(),
        inputs: calculation.inputs,
        result: calculation.result,
        notes: editNotes,
      })

      cancelEditing()
      setMessage('Calculation updated successfully!')
      await loadCalculations()
    } catch (err) {
      console.error('Update failed:', err)
      setError('Failed to update calculation.')
    } finally {
      setBusyId(null)
    }
  }

  async function handleDelete(calculation) {
    const confirmed = window.confirm(
      `Are you sure you want to delete "${calculation.title}"?`
    )

    if (!confirmed) return

    setBusyId(calculation._id)
    setError('')
    setMessage('')

    try {
      await deleteCalculation(calculation._id)

      setCalculations((previous) =>
        previous.filter((item) => item._id !== calculation._id)
      )

      if (editingId === calculation._id) {
        cancelEditing()
      }

      setMessage('Calculation deleted successfully!')
    } catch (err) {
      console.error('Delete failed:', err)
      setError('Failed to delete calculation.')
    } finally {
      setBusyId(null)
    }
  }

  const filteredCalculations = calculations.filter((calculation) => {
    const searchText = search.trim().toLowerCase()

    return (
      calculation.title.toLowerCase().includes(searchText) ||
      calculation.calculatorType.toLowerCase().includes(searchText) ||
      (calculation.notes || '').toLowerCase().includes(searchText)
    )
  })

  return (
    <section>
      <h2>Saved Calculations</h2>
      <p>
        Search, view, edit, and delete your saved engineering calculations.
      </p>

      <div
        style={{
          display: 'flex',
          gap: '12px',
          flexWrap: 'wrap',
          alignItems: 'center',
          marginBottom: '20px',
        }}
      >
        <input
          type="search"
          placeholder="Search saved calculations..."
          aria-label="Search saved calculations"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          style={{
            ...inputStyle,
            flex: '1 1 220px',
            margin: 0,
          }}
        />

        <button
          style={{ ...buttonStyle, background: '#2563eb' }}
          onClick={loadCalculations}
        >
          Refresh
        </button>
      </div>

      {!loading && (
        <p style={{ color: '#64748b', fontSize: '14px' }}>
          Showing {filteredCalculations.length} of {calculations.length}{' '}
          saved calculations
        </p>
      )}

      {loading && <p>Loading calculations...</p>}

      {error && (
        <p role="alert" style={{ color: '#dc2626', fontWeight: 600 }}>
          {error}
        </p>
      )}

      {message && (
        <p role="status" style={{ color: '#047857', fontWeight: 600 }}>
          {message}
        </p>
      )}

      {!loading && !error && calculations.length === 0 && (
        <p>No saved calculations yet.</p>
      )}

      {!loading &&
        !error &&
        calculations.length > 0 &&
        filteredCalculations.length === 0 && (
          <p>No calculations match your search.</p>
        )}

      {!loading &&
        filteredCalculations.map((calculation) => (
          <article
            key={calculation._id}
            style={{
              border: '1px solid #dce3ee',
              borderRadius: '12px',
              padding: '20px',
              marginBottom: '18px',
              background: 'white',
              boxShadow: '0 4px 16px rgba(15, 23, 42, 0.04)',
              overflowWrap: 'anywhere',
            }}
          >
            {editingId === calculation._id ? (
              <>
                <h3 style={{ marginTop: 0 }}>Edit Calculation</h3>

                <label style={{ display: 'block', fontWeight: 600 }}>
                  Calculation Title
                  <input
                    style={inputStyle}
                    type="text"
                    value={editTitle}
                    onChange={(event) => setEditTitle(event.target.value)}
                  />
                </label>

                <label style={{ display: 'block', fontWeight: 600 }}>
                  Notes
                  <textarea
                    style={{ ...inputStyle, minHeight: '90px' }}
                    value={editNotes}
                    onChange={(event) => setEditNotes(event.target.value)}
                    placeholder="Add notes about this calculation..."
                  />
                </label>

                <p>
                  <strong>Calculator:</strong> {calculation.calculatorType}
                </p>

                <h4>Original Inputs</h4>
                <CalculationInputs inputs={calculation.inputs} />

                <h4>Calculated Result</h4>
                <div
                  style={{
                    background: '#ecfdf5',
                    color: '#047857',
                    padding: '14px',
                    borderRadius: '8px',
                    whiteSpace: 'pre-line',
                    marginBottom: '18px',
                  }}
                >
                  {calculation.result}
                </div>

                <div
                  style={{
                    display: 'flex',
                    gap: '10px',
                    flexWrap: 'wrap',
                  }}
                >
                  <button
                    style={{ ...buttonStyle, background: '#059669' }}
                    onClick={() => handleUpdate(calculation)}
                    disabled={busyId === calculation._id}
                  >
                    {busyId === calculation._id
                      ? 'Saving...'
                      : 'Save Changes'}
                  </button>

                  <button
                    style={{ ...buttonStyle, background: '#64748b' }}
                    onClick={cancelEditing}
                    disabled={busyId === calculation._id}
                  >
                    Cancel
                  </button>
                </div>
              </>
            ) : (
              <>
                <h3 style={{ marginTop: 0 }}>{calculation.title}</h3>

                <p style={{ color: '#475569', fontWeight: 600 }}>
                  {calculation.calculatorType}
                </p>

                <h4>Original Inputs</h4>
                <CalculationInputs inputs={calculation.inputs} />

                <h4>Calculated Result</h4>
                <div
                  style={{
                    background: '#ecfdf5',
                    color: '#047857',
                    padding: '14px',
                    borderRadius: '8px',
                    whiteSpace: 'pre-line',
                    fontWeight: 600,
                    marginBottom: '14px',
                  }}
                >
                  {calculation.result}
                </div>

                <p>
                  <strong>Notes:</strong> {calculation.notes || 'None'}
                </p>

                <p
                  style={{
                    color: '#64748b',
                    fontSize: '13px',
                    marginBottom: '18px',
                  }}
                >
                  Saved:{' '}
                  {new Date(calculation.createdAt).toLocaleString()}
                </p>

                <div
                  style={{
                    display: 'flex',
                    gap: '10px',
                    flexWrap: 'wrap',
                  }}
                >
                  <button
                    style={{ ...buttonStyle, background: '#2563eb' }}
                    onClick={() => startEditing(calculation)}
                    disabled={busyId === calculation._id}
                  >
                    Edit
                  </button>

                  <button
                    style={{ ...buttonStyle, background: '#dc2626' }}
                    onClick={() => handleDelete(calculation)}
                    disabled={busyId === calculation._id}
                  >
                    {busyId === calculation._id
                      ? 'Deleting...'
                      : 'Delete'}
                  </button>
                </div>
              </>
            )}
          </article>
        ))}
    </section>
  )
}

export default SavedCalculations
